# mqmeter-java21

A fork of the `mqmeter` JMeter plugin built for Java 21 compatibility.

## Instructions

1. Ensure you have Java 21 and Maven installed.
2. Update your `pom.xml` to use the `release` configuration for Java 21.
3. Build with:

    mvn clean install

4. Copy the generated JAR from `target/` into your JMeter `lib/ext/` folder.
5. Restart JMeter. You should now see:
   - MQ Put Sampler
   - MQ Get Sampler
